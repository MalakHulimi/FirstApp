//
//  Password.swift
//  getart
//
//  Created by Malak  on 06/04/1444 AH.
//

import Foundation
import Foundation
import SwiftUI

struct Password: View {
    init(){
        UITextField.appearance().backgroundColor = UIColor(red: 0.9384715557, green: 0.9561783671, blue: 1, alpha: 1)
    }
    @State private var name: String = ""
    var body: some View {
       
            VStack {
               Image("icon")
                    .resizable()
                    .frame(width: 200,height:240)
                    .padding(.vertical,10)
                
                Spacer()
                    .frame(height: 40)
                
                TextField("Username", text: $name)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 300,height:30)
                    .padding(.vertical,10)
                    Spacer()
                    .frame(height:10 )
                
                TextField("Password", text: $name)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 300,height:30)
                    .padding(.vertical,10)
                    Spacer()
                    .frame(height:10 )
                
                TextField("Confirm Password", text: $name)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 300,height:50)
                    .padding(.vertical,10)
                    Spacer()
                    .frame(height:60)
                   
                NavigationLink(destination: Account()) {
                                                    
                                                    Text("Login")
                                                        .font(.system(size: 20, weight: .bold,design: .default))
                                                        .foregroundColor(.white)
                                                    
                                                        .frame(width: 200,height: 50)
                                                        .background(Color(UIColor(named: "pur")!))
                                                        .cornerRadius(8)
                                                        .padding(.top,100)
                                                }
//                Spacer()
//                    .frame(height:40)
//                Text("Don’t have an account? ")
//                    .foregroundColor(.gray)
//                Text("Sign In")
//                    .foregroundColor(.indigo)

            }
                            
            .padding()
            
            }
        
    }
struct Password_Previews: PreviewProvider {
    static var previews: some View {
        Password()
    }
}
