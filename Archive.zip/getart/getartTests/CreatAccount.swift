//
//  CreatAccount.swift
//  getart
//
//  Created by Malak  on 05/04/1444 AH.
//
import SwiftUI
import Foundation
struct CreatAccount: View{
    init(){
        UITextField.appearance().backgroundColor = UIColor(red: 0.9384715557, green: 0.9561783671, blue: 1, alpha: 1)
    }
    @State private var name: String = ""
    var body: some View{
        ZStack{
            Image("background")
                .resizable()
               .scaledToFit()
                .frame(width: 870,height: 870)
                .cornerRadius(40)
            Image("icon")
                .resizable()
                .scaledToFill()
                .frame(width:150,height: 150)
                .padding(.top, -200.0)
            
            VStack {
               Image("image")
                    .resizable()
                    .frame(width: 200,height:240)
                    .padding(.vertical,10)
                
                Spacer()
                    .frame(height: 40)
                
                
                TextField("Email", text: $name)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 300,height:30)
                    .padding(.vertical,10)
                    Spacer()
                    .frame(height:30 )
              
//                Button("Next"){
//                      }
//                .frame(width: 200,height:50)
//                .buttonStyle(.bordered)
//                .foregroundColor(.white)
//                .background(Color(UIColor(named: "pur")!))
//                .cornerRadius(5)
                NavigationLink(destination: ComCode()) {
                                      
                                      Text("Next")
                                          .font(.system(size: 20, weight: .bold,design: .default))
                                          .foregroundColor(.white)
                                      
                                          .frame(width: 200,height: 50)
                                          .background(Color(UIColor(named: "pur")!))
                                          .cornerRadius(8)
                                          .padding(.top,100)
                                  }
                Spacer()
                    .frame(height:80)
                Text("You may receive SMS notifications from us for ")
                    .foregroundColor(.gray)
                Text("security and login purposes. ")
                    .foregroundColor(.gray)
             
            }
                            
            .padding()
            
            
        }
    }
}
struct CreatAccount_Previews: PreviewProvider {
    static var previews: some View {
        CreatAccount()
    }
}
