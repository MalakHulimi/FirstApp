//
//  getartApp.swift
//  getart
//
//  Created by Malak  on 29/03/1444 AH.
//

import SwiftUI

@main
struct getartApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
